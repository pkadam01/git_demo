# Configure the following general configuration parameters below

# Serial port where the programmable electronic load is connected
serial_port = 'COM8'
