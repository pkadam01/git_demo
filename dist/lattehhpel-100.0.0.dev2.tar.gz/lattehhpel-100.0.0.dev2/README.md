# LATTEHHPEL

This Python library provides an API to interact with programmable electronic load HOECHERL & HACKL ZS series.

The library uses serial communication via the USB port for connecting to the programmable electronic load.
